# Jogo da velha

A Pen created on CodePen.io. Original URL: [https://codepen.io/Corrote/pen/zxObewp](https://codepen.io/Corrote/pen/zxObewp).

